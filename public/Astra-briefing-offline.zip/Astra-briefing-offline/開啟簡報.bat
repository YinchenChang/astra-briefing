@echo off
cd /d "%~dp0"
start "" "Astra-briefing-offline.html"
